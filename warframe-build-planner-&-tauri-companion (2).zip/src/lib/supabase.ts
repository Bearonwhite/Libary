import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Keys for localStorage config on-the-fly
const STORAGE_URL_KEY = 'warframe_supabase_url';
const STORAGE_ANON_KEY = 'warframe_supabase_anon_key';

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConfigured: boolean;
  source: 'env' | 'local' | 'none';
}

/**
 * Retrieves the active Supabase configurations from environment or localStorage
 */
export function getSupabaseConfig(): SupabaseConfig {
  const meta = import.meta as any;
  const envUrl = meta.env?.VITE_SUPABASE_URL;
  const envKey = meta.env?.VITE_SUPABASE_ANON_KEY;

  if (envUrl && envUrl !== 'https://your-project.supabase.co' && envKey && envKey !== 'your-anon-key-here') {
    return {
      url: envUrl,
      anonKey: envKey,
      isConfigured: true,
      source: 'env',
    };
  }

  const localUrl = localStorage.getItem(STORAGE_URL_KEY);
  const localKey = localStorage.getItem(STORAGE_ANON_KEY);

  if (localUrl && localKey) {
    return {
      url: localUrl,
      anonKey: localKey,
      isConfigured: true,
      source: 'local',
    };
  }

  return {
    url: '',
    anonKey: '',
    isConfigured: false,
    source: 'none',
  };
}

/**
 * Saves manual Supabase credentials to localStorage
 */
export function saveSupabaseConfig(url: string, anonKey: string) {
  if (!url || !anonKey) {
    localStorage.removeItem(STORAGE_URL_KEY);
    localStorage.removeItem(STORAGE_ANON_KEY);
  } else {
    localStorage.setItem(STORAGE_URL_KEY, url.trim());
    localStorage.setItem(STORAGE_ANON_KEY, anonKey.trim());
  }
}

/**
 * Clears manual Supabase credentials from localStorage
 */
export function clearSupabaseConfig() {
  localStorage.removeItem(STORAGE_URL_KEY);
  localStorage.removeItem(STORAGE_ANON_KEY);
}

// Singleton client instance
let supabaseInstance: SupabaseClient | null = null;
let currentUrl = '';
let currentKey = '';

/**
 * Gets or initializes the Supabase client
 */
export function getSupabaseClient(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config.isConfigured) {
    return null;
  }

  // If config changed, recreate the client
  if (!supabaseInstance || currentUrl !== config.url || currentKey !== config.anonKey) {
    try {
      supabaseInstance = createClient(config.url, config.anonKey, {
        auth: {
          persistSession: false, // Simple stateless database queries for this custom admin build flow
        }
      });
      currentUrl = config.url;
      currentKey = config.anonKey;
    } catch (e) {
      console.error('Failed to initialize Supabase client:', e);
      return null;
    }
  }

  return supabaseInstance;
}
