/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { Shield, User as UserIcon, Lock, X, Check, ArrowRight, RefreshCw } from 'lucide-react';
import { User, UserRole } from '../types/warframe';
import { getSupabaseClient } from '../lib/supabase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: User) => void;
  simulatedUsers: User[];
}

export default function AuthModal({ 
  isOpen, 
  onClose, 
  onLogin, 
  simulatedUsers
}: AuthModalProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsLoggingIn(true);

    if (!username.trim()) {
      setErrorMessage('กรุณากรอกชื่อผู้ใช้งาน');
      setIsLoggingIn(false);
      return;
    }

    if (!password.trim()) {
      setErrorMessage('กรุณากรอกรหัสผ่าน');
      setIsLoggingIn(false);
      return;
    }

    // 1. Check if Supabase client is configured
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('members')
          .select('id, username, password, role')
          .eq('username', username.trim())
          .maybeSingle();

        if (error) {
          setErrorMessage(`พบข้อผิดพลาดจาก Supabase: ${error.message} (กำลังสลับเข้าโหมดออฟไลน์สำรอง)`);
          // Fail gracefully to local check if db has issues
        } else if (data) {
          if (data.password !== password.trim()) {
            setErrorMessage('รหัสผ่านไม่ถูกต้องบนคลาวด์! กรุณาลองใหม่อีกครั้ง');
            setIsLoggingIn(false);
            return;
          }

          onLogin({
            id: data.id,
            username: data.username,
            role: data.role as UserRole,
            password: data.password
          });
          setIsLoggingIn(false);
          onClose();
          return;
        } else {
          setErrorMessage('ไม่พบชื่อผู้ใช้งานนี้บนระบบคลาวด์ (Supabase)! กรุณาติดต่อแอดมินหรือเปลี่ยนโหมดเชื่อมต่อครับ');
          setIsLoggingIn(false);
          return;
        }
      } catch (err: any) {
        console.error('Exception logging in with Supabase:', err);
        // Fallback to local check if offline/error
      }
    }

    // 2. Offline fallback (local check)
    const matched = simulatedUsers.find(
      u => u.username.toLowerCase() === username.trim().toLowerCase()
    );

    if (!matched) {
      setErrorMessage('ไม่พบชื่อผู้ใช้งานนี้ในคลังแสง! (หากเชื่อมต่อ Supabase แล้ว แสดงว่ายังไม่มีชื่อนี้ในตาราง members)');
      setIsLoggingIn(false);
      return;
    }

    // Verify password
    const enteredPassword = password.trim();
    const userPassword = matched.password || '';

    if (enteredPassword !== userPassword) {
      setErrorMessage('รหัสผ่านไม่ถูกต้อง! กรุณาลองใหม่อีกครั้ง');
      setIsLoggingIn(false);
      return;
    }

    onLogin(matched);
    setIsLoggingIn(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div 
        id="auth-modal-container"
        className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Glow effect */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-amber-500 via-yellow-400 to-cyan-500" />

        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-100 p-1.5 hover:bg-zinc-800 rounded-lg transition-colors"
        >
          <X size={18} />
        </button>

        <div className="p-6 md:p-8">
          <div className="flex flex-col items-center text-center mb-6">
            <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-center text-amber-500 mb-3">
              <Shield size={24} className="animate-pulse" />
            </div>
            <h3 className="text-xl font-bold text-zinc-100 font-sans">
              เข้าสู่ระบบคลังแสง
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              ระบุบัญชีผู้ใช้และรหัสผ่านเพื่อสิทธิ์การใช้งานคลังแสงและบันทึกข้อมูลบิลด์ของคุณ
            </p>
          </div>

          {/* Status Message Alerts */}
          {errorMessage && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs rounded-xl font-semibold leading-relaxed">
              ⚠️ {errorMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">ชื่อผู้ใช้งาน</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500">
                  <UserIcon size={16} />
                </span>
                <input
                  type="text"
                  required
                  placeholder="กรอกชื่อผู้ใช้งานของคุณ"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-sm text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/30 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">รหัสผ่าน</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500">
                  <Lock size={16} />
                </span>
                <input
                  type="password"
                  required
                  placeholder="กรอกรหัสผ่านเพื่อเข้าใช้งาน"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-sm text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/30 transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold rounded-xl text-sm transition-all shadow-lg shadow-amber-500/10 flex items-center justify-center gap-2 mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span>{isLoggingIn ? 'กำลังยืนยันตัวตนกับ Cloud...' : 'ลงชื่อเข้าใช้งานคลังแสง'}</span>
              {isLoggingIn ? <RefreshCw size={16} className="animate-spin" /> : <ArrowRight size={16} />}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
