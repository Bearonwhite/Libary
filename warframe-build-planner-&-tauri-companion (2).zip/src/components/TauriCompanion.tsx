import { useState } from 'react';
import { 
  Cpu, 
  Terminal, 
  Code, 
  Download, 
  ClipboardCheck, 
  ExternalLink, 
  Play, 
  FileCode, 
  Info, 
  Sparkles,
  HelpCircle,
  FolderTree
} from 'lucide-react';

interface CodeSnippet {
  name: string;
  filename: string;
  language: string;
  code: string;
  description: string;
}

export default function TauriCompanion() {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [selectedSnippetTab, setSelectedSnippetTab] = useState<number>(0);
  
  // Bridge Simulation State
  const [selectedCommand, setSelectedCommand] = useState<'get_local_builds' | 'calculate_mod_efficiency' | 'trigger_native_notification' | 'write_backup_to_disk'>('get_local_builds');
  const [consoleLogs, setConsoleLogs] = useState<Array<{ text: string; type: 'info' | 'success' | 'warn' | 'rust' | 'js' }>>([
    { text: '✨ Tauri & Rust IPC Bridge Simulator Initialized.', type: 'info' },
    { text: '🖥️ Desktop Window Webview ready. Listening for frontend invoke requests...', type: 'rust' }
  ]);
  const [isSimulating, setIsSimulating] = useState(false);

  const tauriConfigs: CodeSnippet[] = [
    {
      name: 'tauri.conf.json',
      filename: 'src-tauri/tauri.conf.json',
      language: 'json',
      description: 'ไฟล์กำหนดค่าเริ่มต้นของแอปพลิเคชัน Tauri เช่น ขนาดหน้าต่าง, พอร์ตดีบั๊ก, สิทธิ์เข้าถึง (permissions) และข้อมูลเวอร์ชันเดสก์ท็อป',
      code: `{
  "build": {
    "beforeDevCommand": "npm run dev",
    "beforeBuildCommand": "npm run build",
    "devUrl": "http://localhost:3000",
    "frontendDist": "../dist"
  },
  "package": {
    "productName": "Warframe Build Planner",
    "version": "1.2.0"
  },
  "tauri": {
    "allowlist": {
      "all": false,
      "fs": {
        "all": false,
        "writeFile": true,
        "readFile": true
      },
      "notification": {
        "all": true
      },
      "shell": {
        "all": false,
        "open": true
      }
    },
    "bundle": {
      "active": true,
      "targets": "all",
      "identifier": "com.bearonwhite.warframe.builder",
      "icon": [
        "icons/32x32.png",
        "icons/128x128.png",
        "icons/128x128@2x.png",
        "icons/icon.icns",
        "icons/icon.ico"
      ]
    },
    "windows": [
      {
        "title": "Warframe Build Planner & Companion",
        "width": 1280,
        "height": 768,
        "resizable": true,
        "fullscreen": false,
        "decorations": true
      }
    ]
  }
}`
    },
    {
      name: 'Cargo.toml',
      filename: 'src-tauri/Cargo.toml',
      language: 'toml',
      description: 'ไฟล์กำหนด Dependency และแพ็คเกจฝั่ง Rust สำหรับระบบปฏิบัติการเดสก์ท็อป เช่น tauri, serde (สำหรับแปลง JSON), และ tokio (แบบ Asynchronous)',
      code: `[package]
name = "warframe_build_planner"
version = "1.2.0"
description = "A high-performance desktop client wrapper for Warframe Builder"
authors = ["Bearonwhite"]
edition = "2021"
rust-version = "1.70"

[build-dependencies]
tauri-build = { version = "1.5", features = [] }

[dependencies]
tauri = { version = "1.5", features = ["api-all"] }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
log = "0.4"
env_logger = "0.10"

[profile.release]
panic = "abort" # Reduces binary size
codegen-units = 1 # Better optimizations
lto = true # Link Time Optimization`
    },
    {
      name: 'main.rs',
      filename: 'src-tauri/src/main.rs',
      language: 'rust',
      description: 'โค้ดหลักฝั่ง Rust (Backend) ทำหน้าที่รับคำสั่ง (Commands) ผ่านระบบ IPC (Inter-Process Communication) จากฝั่ง React ของคุณเพื่อเชื่อมกับระบบระบบเดสก์ท็อปโดยตรง',
      code: `#![cfg_attr(
  all(not(debug_assertions), target_os = "windows"),
  windows_subsystem = "windows"
)]

use serde::{Deserialize, Serialize};
use std::fs::File;
use std::io::Write;

// โครงสร้างข้อมูลจำลองการรับส่งข้อมูลบิลด์กับ React
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BuildData {
    id: String,
    title: String,
    warframe_id: String,
    creator_name: String,
}

// 1. คำสั่งสำหรับดึงบิลด์จากเครื่องโลคอล (Rust SQLite/JSON)
#[tauri::command]
fn get_local_builds() -> Result<Vec<BuildData>, String> {
    println!("🦀 Rust Backend: Fetching builds cached locally on machine...");
    
    // จำลองการโหลดข้อมูลบิลด์จากระบบ SQLite
    let mock_builds = vec![
        BuildData {
            id: String::from("saryn_offline"),
            title: String::from("Saryn Prime - Solo Steel Path (Offline Sync)"),
            warframe_id: String::from("saryn"),
            creator_name: String::from("Rust_Operator"),
        }
    ];
    Ok(mock_builds)
}

// 2. คำสั่งประมวลผลคำนวณประสิทธิภาพม็อดความเร็วสูงด้วยมัลติเธรดของ Rust
#[tauri::command]
fn calculate_mod_efficiency(mods_count: usize, total_capacity: i32) -> Result<f64, String> {
    println!("🦀 Rust Backend: Multi-threaded Mod Calculations triggered. mods: {}, capacity: {}", mods_count, total_capacity);
    if total_capacity <= 0 {
        return Err("ความจุพลังงานโหมดต้องมากกว่า 0".into());
    }
    // ประมวลผลสูตรคณิตศาสตร์แบบรวดเร็ว
    let ratio = (mods_count as f64 * 12.5) / (total_capacity as f64);
    Ok(ratio * 100.0)
}

// 3. คำสั่งสั่งเรียกใช้ Native OS Notification
#[tauri::command]
fn trigger_native_notification(app_handle: tauri::AppHandle, message: String) -> Result<(), String> {
    println!("🦀 Rust Backend: Dispatching system OS alert popup...");
    tauri::api::notification::Notification::new(&app_handle.config().tauri.bundle.identifier)
        .title("Warframe Build Companion")
        .body(message)
        .show()
        .map_err(|e| e.to_string())
}

// 4. คำสั่งสำหรับเซฟไฟล์สำรองข้อมูลลง Documents Directory ในเครื่องโดยตรง (Bypass Sandbox ของเบราว์เซอร์)
#[tauri::command]
fn write_backup_to_disk(file_name: String, content: String) -> Result<String, String> {
    println!("🦀 Rust Backend: Writing file directly to system documents library...");
    let user_dirs = std::env::var("USERPROFILE")
        .or_else(|_| std::env::var("HOME"))
        .map_err(|_| "ไม่พบไดเรกทอรีส่วนตัวของผู้ใช้".to_string())?;
        
    let path = std::path::Path::new(&user_dirs)
        .join("Documents")
        .join(&file_name);
        
    let mut file = File::create(&path).map_err(|e| e.to_string())?;
    file.write_all(content.as_bytes()).map_err(|e| e.to_string())?;
    
    Ok(path.to_string_lossy().to_string())
}

fn main() {
  tauri::Builder::default()
    .invoke_handler(tauri::generate_handler![
      get_local_builds,
      calculate_mod_efficiency,
      trigger_native_notification,
      write_backup_to_disk
    ])
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}`
    }
  ];

  const handleCopyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => {
      setCopiedIndex(null);
    }, 2000);
  };

  const clearConsole = () => {
    setConsoleLogs([
      { text: '🗑️ Simulated Tauri terminal logs cleared.', type: 'info' }
    ]);
  };

  // Run Simulated Tauri IPC Call
  const simulateIpc = () => {
    setIsSimulating(true);
    
    const timestamp = () => `[${new Date().toLocaleTimeString()}]`;

    // 1. JS calling
    let jsCode = '';
    let rustHandler = '';
    let mockResult = '';

    if (selectedCommand === 'get_local_builds') {
      jsCode = `import { invoke } from '@tauri-apps/api/core';\nconst builds = await invoke('get_local_builds');`;
      rustHandler = `#[tauri::command]\nfn get_local_builds() -> Result<Vec<BuildData>, String> { ... }`;
      mockResult = `[{ id: "saryn_offline", title: "Saryn Prime - Solo Steel Path (Offline Sync)", warframe_id: "saryn", creator_name: "Rust_Operator" }]`;
    } else if (selectedCommand === 'calculate_mod_efficiency') {
      jsCode = `import { invoke } from '@tauri-apps/api/core';\nconst score = await invoke('calculate_mod_efficiency', { modsCount: 8, totalCapacity: 60 });`;
      rustHandler = `#[tauri::command]\nfn calculate_mod_efficiency(mods_count: usize, total_capacity: i32) -> Result<f64, String> { ... }`;
      mockResult = `166.67% (Optimal Synergic Mod Density)`;
    } else if (selectedCommand === 'trigger_native_notification') {
      jsCode = `import { invoke } from '@tauri-apps/api/core';\nawait invoke('trigger_native_notification', { message: 'ระบบสำรองบิลด์เซฟลงเครื่องเดสก์ท็อปสำเร็จ!' });`;
      rustHandler = `#[tauri::command]\nfn trigger_native_notification(app_handle: tauri::AppHandle, message: String) -> Result<(), String> { ... }`;
      mockResult = `OK (OS Toast Notification Spawned)`;
    } else if (selectedCommand === 'write_backup_to_disk') {
      jsCode = `import { invoke } from '@tauri-apps/api/core';\nconst path = await invoke('write_backup_to_disk', {\n  fileName: "warframe_backup.json",\n  content: JSON.stringify(buildsData)\n});`;
      rustHandler = `#[tauri::command]\nfn write_backup_to_disk(file_name: String, content: String) -> Result<String, String> { ... }`;
      mockResult = `"/Users/operator/Documents/warframe_backup.json" (Saved successfully directly into local file system!)`;
    }

    setConsoleLogs(prev => [
      ...prev,
      { text: `${timestamp()} [Frontend JS] Calling Tauri API command...`, type: 'info' },
      { text: `⚡ JS invoke('${selectedCommand}')`, type: 'js' }
    ]);

    setTimeout(() => {
      setConsoleLogs(prev => [
        ...prev,
        { text: `${timestamp()} [IPC Bridge] Routing request to Rust backend handler...`, type: 'info' },
        { text: `🦀 Rust matched: ${rustHandler.replace(/\n/g, ' ')}`, type: 'rust' }
      ]);

      setTimeout(() => {
        setConsoleLogs(prev => [
          ...prev,
          { text: `${timestamp()} [Rust Execution] Thread ID ${Math.floor(Math.random() * 8) + 1} computed result in 1.42ms. Returning response to Webview context...`, type: 'rust' },
          { text: `✅ Frontend Promise resolved with: ${mockResult}`, type: 'success' }
        ]);
        setIsSimulating(false);
      }, 800);

    }, 600);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* HEADER HERO CARD */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-950 to-zinc-900 border border-zinc-800/60 p-6 md:p-8 rounded-3xl relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 p-8 text-amber-500/5 pointer-events-none hidden lg:block">
          <Cpu size={160} />
        </div>
        
        <div className="max-w-2xl space-y-4">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-500/5 border border-amber-500/20 text-amber-500 text-[9px] font-bold font-mono uppercase tracking-wider rounded-full">
            ⚡ TAURI & RUST COMPANION READY
          </span>
          <h2 className="text-2xl font-bold text-zinc-100 font-mono tracking-tight">
            ยกระดับเว็บสูตรจัดทัพเป็นแอปบนคอมพิวเตอร์ด้วย <span className="text-amber-500 font-extrabold">Tauri & Rust</span>
          </h2>
          <p className="text-xs text-zinc-400 leading-relaxed font-sans">
            เนื่องจาก AI Studio แสดงผลผ่านกรอบ iFrame เบราว์เซอร์เสมือน จึงไม่สามารถ "รัน" คอมไพเลอร์เดสก์ท็อปของ Rust ในเซิร์ฟเวอร์คลาวด์ได้โดยตรง 
            แต่ **บิลด์ React นี้ได้รับการจัดสัดส่วนและเตรียมพร้อม 100% สำหรับการเชื่อมต่อเข้ากับแอปพลิเคชันเดสก์ท็อปแบบ Native** 
            ด้วยการทำงานแบบควบคู่กันของหน้ากากเว็บกับชุดคำสั่งคอมพิวเตอร์ระดับสูงของภาษา Rust
          </p>
          
          <div className="flex flex-wrap gap-3 pt-2">
            <a 
              href="https://tauri.app" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold rounded-xl transition-all shadow-lg shadow-amber-500/15"
            >
              <span>ดาวน์โหลด Tauri CLI</span>
              <ExternalLink size={12} />
            </a>
            <a 
              href="https://rustup.rs" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-semibold rounded-xl transition-all"
            >
              <span>ดาวน์โหลดภาษา Rust</span>
              <ExternalLink size={12} />
            </a>
          </div>
        </div>
      </div>

      {/* TWO COLUMN INTERACTIVE INTERFACE */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
        
        {/* SIMULATOR COLUMN (LEFT 5 COLUMNS ON LARGE SCREENS) */}
        <div className="xl:col-span-5 space-y-6">
          <div className="bg-zinc-900/30 border border-zinc-800 p-5 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0 inline-block" />
                <h3 className="text-xs font-bold text-zinc-300 font-mono uppercase tracking-wider">
                  Tauri-Rust IPC Bridge Simulator
                </h3>
              </div>
              <button 
                onClick={clearConsole}
                className="text-[10px] text-zinc-500 hover:text-zinc-300 font-mono transition-colors"
              >
                Clear Console
              </button>
            </div>
            
            <p className="text-[11px] text-zinc-500 leading-relaxed font-sans">
              ทดสอบการทำงานจำลองการส่งข้อมูลแบบสองทาง (IPC Remote Procedure Call) 
              ระหว่างปุ่มบนเว็บเบราว์เซอร์ฝั่ง React ส่งข้อมูลผ่านพอร์ต Tauri ข้ามไปประมวลผลด้วยฟังก์ชันระบบของภาษา Rust และส่งค่าลัพธ์กลับมาแสดงผลบนจอของคุณแบบเรียลไทม์!
            </p>

            <div className="space-y-3.5 pt-2">
              <label className="block text-[11px] font-semibold text-zinc-400">เลือกคำสั่งที่ต้องการส่งหา Rust (IPC Commands):</label>
              
              <div className="grid grid-cols-1 gap-2.5">
                {[
                  {
                    id: 'get_local_builds',
                    title: '📂 ดึงข้อมูลบิลด์บอร์ดโลคอลในเครื่อง (SQLite)',
                    desc: 'เรียกใช้คำสั่ง Rust เพื่อคิวรี่ตารางฐานข้อมูล SQLite ส่วนตัวที่เซฟไว้แบบออฟไลน์ในตัวเครื่อง'
                  },
                  {
                    id: 'calculate_mod_efficiency',
                    title: '⚡ คำนวณประสิทธิภาพ Synergic Mods ด้วย Rust',
                    desc: 'ให้โมดูล Rust คำนวณสมการความหนาแน่นของการดม็อดและการใช้พลังงานผ่าน Multi-threads'
                  },
                  {
                    id: 'trigger_native_notification',
                    title: '🔔 ยิงแจ้งเตือนเข้าระบบปฏิบัติการ (OS Notification)',
                    desc: 'สั่งใช้ API ระบบเพื่อเรียกแจ้งเตือน Windows/macOS/Linux Toast popups'
                  },
                  {
                    id: 'write_backup_to_disk',
                    title: '💾 เซฟไฟล์ JSON ลงในแฟ้ม Documents ทันที',
                    desc: 'ใช้คำสั่ง Rust เขียนไฟล์สำรองสูตรบิลด์ลงในดิสก์คอมพิวเตอร์ของคุณโดยตรง'
                  }
                ].map(cmd => (
                  <button
                    key={cmd.id}
                    onClick={() => !isSimulating && setSelectedCommand(cmd.id as any)}
                    disabled={isSimulating}
                    className={`w-full text-left p-4 rounded-xl border transition-all flex flex-col gap-1.5 ${
                      selectedCommand === cmd.id 
                        ? 'bg-amber-500/[0.04] border-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.12)]' 
                        : 'bg-zinc-950/60 border-zinc-900 hover:bg-zinc-900/40 hover:border-zinc-800'
                    } ${isSimulating ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <span className={`text-xs font-bold ${selectedCommand === cmd.id ? 'text-amber-400' : 'text-zinc-300'}`}>
                      {cmd.title}
                    </span>
                    <span className={`text-[11px] leading-relaxed ${selectedCommand === cmd.id ? 'text-amber-500/80' : 'text-zinc-500'}`}>
                      {cmd.desc}
                    </span>
                  </button>
                ))}
              </div>

              {/* Invoke Trigger */}
              <button
                onClick={simulateIpc}
                disabled={isSimulating}
                className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 text-xs font-bold rounded-xl transition-all shadow-lg shadow-amber-500/10"
              >
                <Play size={14} className={isSimulating ? 'animate-spin' : ''} />
                <span>{isSimulating ? 'Rust กำลังประมวลผล...' : 'ยิงคำสั่งเรียกใช้ Rust Command (Invoke)'}</span>
              </button>
            </div>

            {/* LIVE SIMULATED TERMINAL DISPLAY */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500">
                <span className="flex items-center gap-1"><Terminal size={12} /> TAURI IPC BRIDGE MONITOR</span>
                <span>Active Link: 127.0.0.1</span>
              </div>
              <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-4 font-mono text-[11px] h-64 overflow-y-auto space-y-2.5 custom-scrollbar select-text">
                {consoleLogs.map((log, idx) => (
                  <div key={idx} className="leading-relaxed break-words">
                    {log.type === 'info' && (
                      <span className="text-zinc-500">{log.text}</span>
                    )}
                    {log.type === 'success' && (
                      <span className="text-emerald-400 font-semibold">{log.text}</span>
                    )}
                    {log.type === 'warn' && (
                      <span className="text-amber-500 font-semibold">{log.text}</span>
                    )}
                    {log.type === 'rust' && (
                      <span className="text-amber-500 font-medium">{log.text}</span>
                    )}
                    {log.type === 'js' && (
                      <span className="text-sky-400">{log.text}</span>
                    )}
                  </div>
                ))}
                {isSimulating && (
                  <div className="flex items-center gap-1.5 text-amber-500/60 animate-pulse text-[10px]">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                    <span>Awaiting Rust thread pool signals...</span>
                  </div>
                )}
              </div>
            </div>

          </div>
        </div>

        {/* CODE VIEWER COLUMN (RIGHT 7 COLUMNS ON LARGE SCREENS) */}
        <div className="xl:col-span-7 space-y-6">
          <div className="bg-zinc-900/30 border border-zinc-800 p-5 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Code size={16} className="text-amber-500" />
                <h3 className="text-xs font-bold text-zinc-300 font-mono uppercase tracking-wider">
                  Tauri Configuration Files Generator
                </h3>
              </div>
              
              <span className="text-[10px] bg-zinc-950 px-2 py-1 rounded border border-zinc-850 text-zinc-500 font-mono font-bold">
                READY TO COPY
              </span>
            </div>

            <p className="text-[11px] text-zinc-500 leading-relaxed font-sans">
              คลิกเลือกแท็บของไฟล์คอนฟิกด้านล่างนี้ คุณสามารถนำเอาโค้ดเหล่านี้ไปแปะลงในโปรเจกต์โฟลเดอร์ฝั่งเครื่องส่วนตัวของคุณเพื่อรัน Tauri ได้ทันที ไม่จำเป็นต้องเขียนใหม่!
            </p>

            {/* TAB SELECTOR FOR FILES */}
            <div className="flex border-b border-zinc-850 gap-1.5 overflow-x-auto scrollbar-none pb-1">
              {tauriConfigs.map((snippet, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedSnippetTab(idx)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-t-xl text-xs font-semibold font-mono border-b-2 transition-all whitespace-nowrap ${
                    selectedSnippetTab === idx
                      ? 'border-amber-500 text-amber-500 bg-amber-500/5'
                      : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850/20'
                  }`}
                >
                  <FileCode size={13} />
                  <span>{snippet.name}</span>
                </button>
              ))}
            </div>

            {/* Selected File Details */}
            <div className="bg-zinc-950/40 p-4 rounded-xl border border-zinc-850/60 space-y-2">
              <div className="flex justify-between items-center text-[11px]">
                <span className="font-mono font-bold text-amber-500/80 bg-amber-500/5 px-2 py-0.5 rounded border border-amber-500/20">
                  {tauriConfigs[selectedSnippetTab].filename}
                </span>
                <button
                  onClick={() => handleCopyToClipboard(tauriConfigs[selectedSnippetTab].code, selectedSnippetTab)}
                  className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-100 font-medium transition-all"
                >
                  {copiedIndex === selectedSnippetTab ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <ClipboardCheck size={12} /> คัดลอกสำเร็จ!
                    </span>
                  ) : (
                    <>
                      <Download size={12} />
                      <span>Copy Code (คัดลอกโค้ด)</span>
                    </>
                  )}
                </button>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
                {tauriConfigs[selectedSnippetTab].description}
              </p>
            </div>

            {/* CODE PREVIEW BOX */}
            <div className="relative">
              <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-4 overflow-x-auto font-mono text-[11px] max-h-96 text-zinc-300 leading-relaxed scrollbar-thin select-text">
                <pre>{tauriConfigs[selectedSnippetTab].code}</pre>
              </div>
              <div className="absolute bottom-3 right-3 opacity-60 hover:opacity-100 transition-opacity">
                <span className="text-[9px] bg-zinc-900 px-2 py-1 rounded border border-zinc-800 text-zinc-500 uppercase font-mono font-bold">
                  {tauriConfigs[selectedSnippetTab].language}
                </span>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* RUST LOCAL INSTALLATION STEP BY STEP GUIDE */}
      <div className="bg-zinc-900/30 border border-zinc-800 p-6 rounded-2xl space-y-6">
        <div className="flex items-center gap-2 border-b border-zinc-850 pb-3">
          <FolderTree size={18} className="text-amber-500" />
          <h3 className="text-xs font-bold text-zinc-200 font-mono uppercase tracking-wider">
            คู่มือการติดตั้งแอปพลิเคชันเดสก์ท็อปบนเครื่องคอมพิวเตอร์ของคุณ (LOCAL STEP-BY-STEP)
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-500 flex items-center justify-center text-xs font-bold font-mono">
                01
              </span>
              <h4 className="text-xs font-bold text-zinc-300">ติดตั้ง Rust & Node.js ในเครื่อง</h4>
            </div>
            <p className="text-[11px] text-zinc-500 leading-relaxed font-sans">
              เปิดเบราว์เซอร์แล้วไปที่ <a href="https://rustup.rs" target="_blank" rel="noopener noreferrer" className="text-amber-500 hover:underline">rustup.rs</a> เพื่อรันคำสั่งดาวน์โหลด Rust Compiler ติดตั้งลงเครื่องคอมพิวเตอร์ของคุณ (จำเป็นสำหรับคอมไพล์โค้ด backend ของ Tauri)
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-500 flex items-center justify-center text-xs font-bold font-mono">
                02
              </span>
              <h4 className="text-xs font-bold text-zinc-300">ติดตั้ง Tauri SDK ในโปรเจกต์</h4>
            </div>
            <p className="text-[11px] text-zinc-500 leading-relaxed font-sans">
              ใช้ settings เมนูด้านบนซ้ายของ AI Studio เพื่อดาวน์โหลดโปรเจกต์ของคุณเป็น **ZIP** แตกไฟล์แล้วเปิดด้วย Terminal ในเครื่องของคุณ จากนั้นรันคำสั่งติดตั้งแพ็คเกจ:
              <code className="block mt-2 px-2 py-1.5 bg-zinc-950 border border-zinc-900 rounded-md font-mono text-[10px] text-amber-500">
                npm install @tauri-apps/api @tauri-apps/cli
              </code>
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-500 flex items-center justify-center text-xs font-bold font-mono">
                03
              </span>
              <h4 className="text-xs font-bold text-zinc-300">เริ่มต้นรันโปรเจกต์ด้วยคอมพิวเตอร์</h4>
            </div>
            <p className="text-[11px] text-zinc-500 leading-relaxed font-sans">
              สร้างโฟลเดอร์ <code className="text-amber-500 font-mono">src-tauri</code> แล้วนำไฟล์ <code className="text-amber-500 font-mono">Cargo.toml</code>, <code className="text-amber-500 font-mono">tauri.conf.json</code>, และ <code className="text-amber-500 font-mono">src/main.rs</code> ไปวางไว้ตามไดเรกทอรีด้านบน จากนั้นรันดีบั๊กเพื่อเปิดแอปทันที:
              <code className="block mt-2 px-2 py-1.5 bg-zinc-950 border border-zinc-900 rounded-md font-mono text-[10px] text-amber-500">
                npx tauri dev
              </code>
            </p>
          </div>
        </div>

        {/* PRO-TIP WARNING FOOTER */}
        <div className="bg-zinc-950 border border-zinc-900 p-4.5 rounded-xl flex gap-3 items-start">
          <Info className="text-amber-500 shrink-0 mt-0.5" size={16} />
          <div className="space-y-1">
            <h5 className="text-[11px] font-bold text-zinc-300 font-mono uppercase">PRO OPERATOR TIP: WEBVIEW VS RUST COMMUNICATION</h5>
            <p className="text-[10px] text-zinc-500 leading-relaxed font-sans">
              เมื่อคุณนำเอาไปรันบนเดสก์ท็อปในเครื่องจริงแล้ว คุณสามารถนำเอาคำสั่งเรียกใช้ Tauri API เช่น <code className="text-amber-400 bg-amber-500/5 px-1 rounded font-mono">invoke('write_backup_to_disk', &#123; fileName: "...", content: "..." &#125;)</code> ไปเขียนเพิ่มไว้ในฟังก์ชันการกดเซฟบิลด์ของคุณ และเขียนโค้ด Rust คอยเซฟข้อมูลลงใน SQLite ในคอมได้อย่างปลอดภัยสูงสุด โดยข้อมูลจะไม่สูญหายแม้ว่าจะเคลียร์แคชของเบราว์เซอร์ก็ดี!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
