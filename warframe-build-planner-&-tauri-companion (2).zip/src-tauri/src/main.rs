#![cfg_attr(
  all(not(debug_assertions), target_os = "windows"),
  windows_subsystem = "windows"
)]

use serde::{Deserialize, Serialize};
use std::fs::File;
use std::io::Write;
use reqwest::header::{HeaderMap, HeaderValue, AUTHORIZATION};

// โครงสร้างข้อมูลที่ตรงกับตารางใน Supabase Database ของคุณ
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SupabaseBuild {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub id: Option<String>,
    pub title: String,
    pub warframe_id: String,
    pub creator_name: String,
    pub helminth_ability: Option<String>,
    pub main_mods: Option<String>, // บันทึกเป็น JSON string ของ Array ม็อด
    pub arcane_1: Option<String>,
    pub arcane_2: Option<String>,
    pub description: Option<String>,
}

// 1. ดึงข้อมูลบิลด์ทั้งหมดจากตาราง "warframe_builds" ใน Supabase
#[tauri::command]
async fn fetch_builds_from_supabase(supabase_url: String, supabase_key: String) -> Result<Vec<SupabaseBuild>, String> {
    println!("🦀 [Rust] กำลังเชื่อมต่อเพื่อดึงข้อมูลจาก Supabase API...");
    
    let client = reqwest::Client::new();
    let url = format!("{}/rest/v1/warframe_builds?select=*", supabase_url);
    
    let mut headers = HeaderMap::new();
    headers.insert("apikey", HeaderValue::from_str(&supabase_key).map_err(|e| e.to_string())?);
    headers.insert(AUTHORIZATION, HeaderValue::from_str(&format!("Bearer {}", supabase_key)).map_err(|e| e.to_string())?);
    
    let response = client.get(&url)
        .headers(headers)
        .send()
        .await
        .map_err(|e| format!("ไม่สามารถเชื่อมต่อ Supabase: {}", e))?;
        
    if !response.status().is_success() {
        let err_body = response.text().await.unwrap_or_default();
        return Err(format!("Supabase ส่งข้อผิดพลาดกลับมา: {}", err_body));
    }
    
    let builds: Vec<SupabaseBuild> = response.json()
        .await
        .map_err(|e| format!("แปลงโครงสร้าง JSON ไม่สำเร็จ: {}", e))?;
        
    println!("🦀 [Rust] โหลดข้อมูลบิลด์สำเร็จ ทั้งหมด {} รายการ!", builds.len());
    Ok(builds)
}

// 2. ส่งบิลด์ใหม่ขึ้นไปเซฟใน Supabase
#[tauri::command]
async fn insert_build_to_supabase(
    supabase_url: String, 
    supabase_key: String, 
    build: SupabaseBuild
) -> Result<SupabaseBuild, String> {
    println!("🦀 [Rust] กำลังเพิ่มสูตรบิลด์ใหม่ '{}' ลงใน Supabase...", build.title);
    
    let client = reqwest::Client::new();
    let url = format!("{}/rest/v1/warframe_builds", supabase_url);
    
    let mut headers = HeaderMap::new();
    headers.insert("apikey", HeaderValue::from_str(&supabase_key).map_err(|e| e.to_string())?);
    headers.insert(AUTHORIZATION, HeaderValue::from_str(&format!("Bearer {}", supabase_key)).map_err(|e| e.to_string())?);
    headers.insert("Prefer", HeaderValue::from_static("return=representation"));
    
    let response = client.post(&url)
        .headers(headers)
        .json(&build)
        .send()
        .await
        .map_err(|e| format!("เกิดข้อผิดพลาดในการส่งข้อมูล: {}", e))?;
        
    if !response.status().is_success() {
        let err_body = response.text().await.unwrap_or_default();
        return Err(format!("ไม่สามารถบันทึกลง Supabase: {}", err_body));
    }
    
    let created_builds: Vec<SupabaseBuild> = response.json()
        .await
        .map_err(|e| format!("แปลงข้อมูลขากลับสำเร็จล้มเหลว: {}", e))?;
        
    if created_builds.is_empty() {
        return Err("ไม่ได้รับข้อมูลการตอบกลับจาก Supabase".into());
    }
    
    println!("🦀 [Rust] บันทึกบิลด์ '{}' ขึ้น Cloud Supabase สำเร็จ!", build.title);
    Ok(created_builds[0].clone())
}

// 3. คำนวณความจุและประสิทธิภาพม็อดผ่าน Rust Native CPU thread
#[tauri::command]
fn calculate_mod_efficiency(mods_count: usize, total_capacity: i32) -> Result<f64, String> {
    if total_capacity <= 0 {
        return Err("ความจุพลังงานโหมดต้องมากกว่า 0".into());
    }
    let ratio = (mods_count as f64 * 12.5) / (total_capacity as f64);
    Ok(ratio * 100.0)
}

// 4. บันทึกสำรองข้อมูลลงเครื่องเดสก์ท็อปโดยตรง (Bypass Browser Sandbox)
#[tauri::command]
fn write_backup_to_disk(file_name: String, content: String) -> Result<String, String> {
    let user_dirs = std::env::var("USERPROFILE")
        .or_else(|_| std::env::var("HOME"))
        .map_err(|_| "ไม่พบไดเรกทอรีส่วนตัวของผู้ใช้".to_string())?;
        
    let path = std::path::Path::new(&user_dirs)
        .join("Documents")
        .join(&file_name);
        
    let mut file = File::create(&path).map_err(|e| e.to_string())?;
    file.write_all(content.as_bytes()).map_err(|e| e.to_string())?;
    
    Ok(path.to_string_lossy().to_string())
}

fn main() {
  tauri::Builder::default()
    .invoke_handler(tauri::generate_handler![
      fetch_builds_from_supabase,
      insert_build_to_supabase,
      calculate_mod_efficiency,
      write_backup_to_disk
    ])
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}
