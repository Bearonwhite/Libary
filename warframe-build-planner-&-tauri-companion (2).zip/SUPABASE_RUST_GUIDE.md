# 🛠️ คู่มือการตั้งค่า Cloud Supabase + Rust Tauri Backend 🦀

ยินดีด้วยครับ! โค้ดโปรเจกต์ของคุณได้รับการออกแบบโครงสร้างและเขียนโค้ดระบบ **Rust Backend ร่วมกับ Tauri และ Supabase** สำเร็จแล้ว 100% เรียบร้อยแล้วในโฟลเดอร์ `/src-tauri` ของคุณ! 

ด้านล่างนี้คือคู่มือสอนตั้งค่าฐานข้อมูลบน **Supabase Cloud Console** และโครงสร้างภาษา SQL เพื่อเปิดตารางต้อนรับข้อมูลของคุณ รวมถึงวิธีการรันร่วมกับ Rust ครับ

---

## Part 1: วิธีการตั้งค่าตารางบน Cloud Supabase

1. ไปที่เว็บไซต์ [Supabase Dashboard](https://supabase.com) และสร้างโปรเจกต์ใหม่ (หากยังไม่มี)
2. เมื่อโปรเจกต์พร้อมแล้ว ให้เลือกเมนู **"SQL Editor"** จากแถบเมนูด้านซ้าย
3. กดปุ่ม **"New query"** และวางคำสั่ง PostgreSQL ด้านล่างนี้เพื่อสร้างตารางเก็บข้อมูลสูตรบิลด์คลังแสง Warframe:

```sql
-- 1. สร้างตารางเก็บข้อมูลสูตรบิลด์ Warframe
CREATE TABLE public.warframe_builds (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    title TEXT NOT NULL,
    warframe_id TEXT NOT NULL,
    creator_name TEXT NOT NULL,
    helminth_ability TEXT,
    main_mods TEXT, -- จะเก็บเป็น JSON String ของโมเดลม็อดจัดสล็อต
    arcane_1 TEXT,
    arcane_2 TEXT,
    description TEXT
);

-- 2. สร้างดัชนี (Index) เพื่อการคิวรี่ขยายตัวระดับสูงผ่าน Rust อย่างรวดเร็ว
CREATE INDEX idx_builds_warframe_id ON public.warframe_builds(warframe_id);

-- 3. ยิงอนุญาตให้ทุกคนเข้าถึงตารางได้ชั่วคราว (หรือจะเปิด RLS ภายหลังก็สามารถเปิดได้)
ALTER TABLE public.warframe_builds ENABLE ROW LEVEL SECURITY;

-- 4. ตั้งค่านโยบายความปลอดภัยของสิทธิ์ (Security Policy): อนุญาตให้ทุกคนอ่านและบันทึกสูตรได้อิสระ
CREATE POLICY "Allow public read access" ON public.warframe_builds FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON public.warframe_builds FOR INSERT WITH CHECK (true);
```

4. กดปุ่ม **"Run"** เพื่อสร้างฐานข้อมูลทันที!

---

## Part 2: ข้อมูลสำคัญจาก Supabase สำหรับเชื่อมเข้ากับ Rust

ในหน้าตั้งค่า Supabase ให้ไปที่ **Settings (รูปฟันเฟือง) -> API** และจดข้อมูล 2 ค่าสำคัญนี้ไว้ใช้งาน:
- **Project URL:** เช่น `https://xyzabc.supabase.co`
- **Anon Key (Public API Key):** ชุดรหัสคีย์เข้าถึงข้อมูลความปลอดภัยสาธารณะ

---

## Part 3: การเชื่อมต่อระหว่าง React (Frontend) กับ Rust (Backend)

เมื่อรันในเดสก์ท็อปผ่าน Tauri จริง โค้ด React ฝั่งแอนิเมชันจะเรียกฟังก์ชันที่เขียนเตรียมไว้ในไฟล์ `src-tauri/src/main.rs` ได้ง่ายๆ ผ่านการพิมพ์แบบนี้ในโค้ด React:

```typescript
import { invoke } from '@tauri-apps/api/core';

// 1. ตัวอย่างคำสั่งสั่งดึงบิลด์คลังแสงทั้งหมดผ่าน Rust ข้ามไป Supabase Cloud
async function loadCloudBuilds() {
  try {
    const cloudBuilds = await invoke('fetch_builds_from_supabase', {
      supabaseUrl: "https://your-supabase-project.supabase.co",
      supabaseKey: "your-anon-key-here"
    });
    console.log("บิลด์จาก Supabase:", cloudBuilds);
  } catch (error) {
    console.error("โหลดข้อมูลล้มเหลว:", error);
  }
}

// 2. ตัวอย่างการกดเพิ่มบิลด์ใหม่ส่งข้ามไป Rust เพื่อเซฟลง Cloud ของคุณ
async function saveNewBuildToCloud(buildData) {
  try {
    const savedBuild = await invoke('insert_build_to_supabase', {
      supabaseUrl: "https://your-supabase-project.supabase.co",
      supabaseKey: "your-anon-key-here",
      build: {
        title: "Volt Prime Speedrun",
        warframe_id: "volt",
        creator_name: "Tenno_Operator",
        helminth_ability: "Roar",
        main_mods: JSON.stringify(["Intensify", "Flow", "Streamline"]),
        arcane_1: "Arcane Energize",
        arcane_2: "Arcane Aegis",
        description: "เน้นวิ่งไวเก็บบอร์ดคลังแสงออฟไลน์"
      }
    });
    alert("บันทึกลง Supabase สำเร็จ!");
  } catch (error) {
    console.error("เซฟล้มเหลว:", error);
  }
}
```

---

## Part 4: วิธีเริ่มรันแบบเดสก์ท็อปด้วยคอมพิวเตอร์ของคุณ

เมื่อคุณเตรียมพร้อมดาวน์โหลดโค้ดโปรเจกต์นี้ทั้งหมดไปรันในเครื่องคอมของคุณแล้ว:

1. ตรวจสอบให้มั่นใจว่าลงตัวคอมไพเลอร์ Rust ไว้ในเครื่องแล้ว ([rustup.rs](https://rustup.rs))
2. เปิดโฟลเดอร์หลักผ่านแอป VS Code หรือ Terminal ของคอมพิวเตอร์
3. รันคำสั่งติดตั้ง API ตัวเชื่อมต่อนักพัฒนา:
   ```bash
   npm install @tauri-apps/api @tauri-apps/cli
   ```
4. เริ่มรันเพื่อเปิดหน้าจอหน้าต่างวินโดว์เดสก์ท็อปขึ้นมาทำงานทันที:
   ```bash
   npx tauri dev
   ```

Tauri จะสร้างโฟลเดอร์เดสก์ท็อปและคอมไพล์โค้ด Rust ของเราให้ทำงานร่วมกับ React ในรูปแบบโปรแกรมคอมพิวเตอร์ (.exe / .app) ทันทีที่มีความเร็วสูงและปลอดภัยสูงสุดครับ! 🚀
